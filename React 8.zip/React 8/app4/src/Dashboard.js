import React from "react";
import { Link, useNavigate } from "react-router-dom";

function Dashboard() {

  const navigate = useNavigate();

  const user =
    JSON.parse(localStorage.getItem("authUser")) ||
    JSON.parse(sessionStorage.getItem("authUser"));

  const logout = () => {

    localStorage.removeItem("authUser");
    sessionStorage.removeItem("authUser");

    navigate("/login");
  };

  return (

    <div className="container">

      <h1>Task Manager Dashboard</h1>

      <hr />

      <h3>
        Welcome, {user ? user.username : "User"}
      </h3>

      <br />

      <Link to="/tasks" className="btn btn-primary">
        View Tasks
      </Link>

      {" "}

      <Link to="/add-task" className="btn btn-success">
        Add Task
      </Link>

      {" "}

      <Link to="/completed" className="btn btn-info">
        Completed Tasks
      </Link>

      {" "}

      <button
        onClick={logout}
        className="btn btn-danger"
      >
        Logout
      </button>

    </div>
  );
}

export default Dashboard;