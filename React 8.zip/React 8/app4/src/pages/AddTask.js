import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function AddTask({ addTask }) {

  const navigate = useNavigate();

  const [header, setHeader] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState("Medium");
  const [category, setCategory] = useState("Academic");
  const [status, setStatus] = useState("Raised");

  const handleSubmit = (e) => {

    e.preventDefault();

    const task = {
      header,
      description,
      priority,
      category,
      status
    };

    addTask(task);

    navigate("/tasks");
  };

  return (
    <div className="container">

      <h1>Add Task</h1>

      <form onSubmit={handleSubmit}>

        <label>Task Header</label>

        <input
          type="text"
          value={header}
          onChange={(e) => setHeader(e.target.value)}
          required
        />

        <label>Task Description</label>

        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
        />

        <label>Priority</label>

        <select
          value={priority}
          onChange={(e) => setPriority(e.target.value)}
        >
          <option>High</option>
          <option>Medium</option>
          <option>Low</option>
        </select>

        <label>Category</label>

        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          <option>Academic</option>
          <option>Personal</option>
        </select>

        <label>Status</label>

        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
        >
          <option>Raised</option>
          <option>Pending</option>
          <option>Closed</option>
        </select>

        <p>
          <b>Due Date:</b> 28 Aug 2026
        </p>

        <button type="submit">
          Add Task
        </button>

      </form>

    </div>
  );
}

export default AddTask;