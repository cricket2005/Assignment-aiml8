import React from "react";
import { Link } from "react-router-dom";

function CompletedTasks({ tasks }) {

  const completedTasks = tasks.filter(
    (task) => task.status === "Closed"
  );

  return (
    <div className="container">

      <h1>Completed Tasks</h1>

      {completedTasks.length === 0 ? (

        <h3>No completed tasks.</h3>

      ) : (

        completedTasks.map((task) => (

          <div className="task-card" key={task.id}>

            <h2>{task.header}</h2>

            <p>{task.description}</p>

            <p>
              <b>Priority:</b> {task.priority}
            </p>

            <p>
              <b>Category:</b> {task.category}
            </p>

            <p>
              <b>Status:</b> Closed
            </p>

            <Link to={`/task/${task.id}`}>
              <button>
                View Details
              </button>
            </Link>

          </div>

        ))

      )}

    </div>
  );
}

export default CompletedTasks;