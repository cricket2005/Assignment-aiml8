import React, { useState } from "react";
import { Link } from "react-router-dom";

function Tasks({ tasks, deleteTask, completeTask }) {

  const [filter, setFilter] = useState("All");

  const filteredTasks =
    filter === "All"
      ? tasks
      : tasks.filter(
          (task) => task.status === filter
        );

  return (
    <div className="container">

      <h1>Tasks</h1>

      <div className="filter">

        <label>Filter:</label>

        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        >
          <option>All</option>
          <option>Raised</option>
          <option>Pending</option>
          <option>Closed</option>
        </select>

      </div>

      {filteredTasks.length === 0 ? (
        <h3>No tasks found.</h3>
      ) : (

        filteredTasks.map((task) => (

          <div className="task-card" key={task.id}>

            <h2>{task.header}</h2>

            <p>{task.description}</p>

            <p>
              <b>Priority:</b> {task.priority}
            </p>

            <p>
              <b>Category:</b> {task.category}
            </p>

            <p>
              <b>Raised:</b> {task.raisedDate}
            </p>

            <p>
              <b>Due:</b> {task.dueDate}
            </p>

            <p>
              <b>Status:</b> {task.status}
            </p>

            <Link to={`/task/${task.id}`}>
              <button>
                View Details
              </button>
            </Link>

            {task.status !== "Closed" && (
              <button
                onClick={() => completeTask(task.id)}
              >
                Complete
              </button>
            )}

            <button
              className="delete"
              onClick={() => deleteTask(task.id)}
            >
              Delete
            </button>

          </div>

        ))

      )}

    </div>
  );
}

export default Tasks;