import React from "react";
import { Link } from "react-router-dom";

function Dashboard({ tasks }) {

  const total = tasks.length;

  const completed = tasks.filter(
    (task) => task.status === "Closed"
  ).length;

  const pending = tasks.filter(
    (task) => task.status === "Pending"
  ).length;

  const raised = tasks.filter(
    (task) => task.status === "Raised"
  ).length;

  return (
    <div className="container">

      <h1>Dashboard</h1>

      <div className="dashboard">

        <div className="box">
          <h2>{total}</h2>
          <p>Total Tasks</p>
        </div>

        <div className="box">
          <h2>{raised}</h2>
          <p>Raised</p>
        </div>

        <div className="box">
          <h2>{pending}</h2>
          <p>Pending</p>
        </div>

        <div className="box">
          <h2>{completed}</h2>
          <p>Completed</p>
        </div>

      </div>

      <Link to="/add-task">
        <button className="add-button">
          + Add New Task
        </button>
      </Link>

    </div>
  );
}

export default Dashboard;