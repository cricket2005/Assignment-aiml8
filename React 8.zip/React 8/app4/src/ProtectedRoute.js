import React from "react";
import { Navigate } from "react-router-dom";

function ProtectedRoute({ children }) {

  const localUser = localStorage.getItem("authUser");
  const sessionUser = sessionStorage.getItem("authUser");

  const user = localUser || sessionUser;

  if (!user) {

    return <Navigate to="/login" replace />;

  }

  return children;
}

export default ProtectedRoute;