import React from "react";
import { Link } from "react-router-dom";

function Tasks() {

  const tasks = [
    {
      id: 1,
      header: "Complete React Assignment",
      priority: "High",
      category: "Academic",
      status: "Pending"
    },
    {
      id: 2,
      header: "Buy Groceries",
      priority: "Medium",
      category: "Personal",
      status: "Raised"
    }
  ];

  return (

    <div className="container">

      <h2>All Tasks</h2>

      <hr />

      {tasks.map((task) => (

        <div
          key={task.id}
          className="panel panel-default"
        >

          <div className="panel-heading">

            <h4>{task.header}</h4>

          </div>

          <div className="panel-body">

            <p>
              <b>Priority:</b> {task.priority}
            </p>

            <p>
              <b>Category:</b> {task.category}
            </p>

            <p>
              <b>Status:</b> {task.status}
            </p>

            <Link
              to={`/task/${task.id}`}
              className="btn btn-primary"
            >
              View Details
            </Link>

          </div>

        </div>

      ))}

      <Link to="/" className="btn btn-default">
        Back Dashboard
      </Link>

    </div>
  );
}

export default Tasks;