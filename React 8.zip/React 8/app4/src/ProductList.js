import React from "react";

function ProductList({ products, addToCart }) {

  return (
    <div>

      <h2>Product List</h2>

      <div className="product-container">

        {products.map(product => (

          <div className="product-card" key={product.id}>

            <h3>{product.name}</h3>

            <p>Price: ₹{product.price}</p>

            <button
              onClick={() => addToCart(product)}
            >
              Add to Cart
            </button>

          </div>

        ))}

      </div>

    </div>
  );
}

export default ProductList;