import React, { useState, useEffect } from "react";

function EmployeeForm({
  addEmployee,
  editingEmployee,
  updateEmployee
}) {

  const [form, setForm] = useState({
    name: "",
    employeeId: "",
    department: "",
    gender: "",
    phone: "",
    localAddress: "",
    permanentAddress: ""
  });

  // Load employee data when Edit is clicked
  useEffect(() => {

    if (editingEmployee) {
      setForm(editingEmployee);
    }

  }, [editingEmployee]);

  // Input Change
  const handleChange = (e) => {

    setForm({
      ...form,
      [e.target.name]: e.target.value
    });

  };

  // Submit
  const handleSubmit = (e) => {

    e.preventDefault();

    if (
      !form.name ||
      !form.employeeId ||
      !form.department ||
      !form.gender ||
      !form.phone
    ) {
      alert("Please fill all required fields");
      return;
    }

    if (editingEmployee) {

      updateEmployee(form);

    } else {

      addEmployee(form);

      setForm({
        name: "",
        employeeId: "",
        department: "",
        gender: "",
        phone: "",
        localAddress: "",
        permanentAddress: ""
      });

    }

  };

  return (

    <form className="employee-form" onSubmit={handleSubmit}>

      <h2>
        {editingEmployee
          ? "Edit Employee"
          : "Add Employee"}
      </h2>

      <div className="form-grid">

        <input
          type="text"
          name="name"
          placeholder="Employee Name"
          value={form.name}
          onChange={handleChange}
        />

        <input
          type="text"
          name="employeeId"
          placeholder="Employee ID"
          value={form.employeeId}
          onChange={handleChange}
        />

        <select
          name="department"
          value={form.department}
          onChange={handleChange}
        >
          <option value="">Select Department</option>
          <option value="IT">IT</option>
          <option value="HR">HR</option>
          <option value="Accounts">Accounts</option>
          <option value="Production">Production</option>
          <option value="Marketing">Marketing</option>
        </select>

        <select
          name="gender"
          value={form.gender}
          onChange={handleChange}
        >
          <option value="">Select Gender</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
          <option value="Other">Other</option>
        </select>

        <input
          type="tel"
          name="phone"
          placeholder="Phone Number"
          value={form.phone}
          onChange={handleChange}
        />

        <input
          type="text"
          name="localAddress"
          placeholder="Local Address"
          value={form.localAddress}
          onChange={handleChange}
        />

        <input
          type="text"
          name="permanentAddress"
          placeholder="Permanent Address"
          value={form.permanentAddress}
          onChange={handleChange}
        />

      </div>

      <button type="submit">
        {editingEmployee
          ? "Update Employee"
          : "Add Employee"}
      </button>

    </form>
  );
}

export default EmployeeForm;