import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function Login() {

  const navigate = useNavigate();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(false);

  const [error, setError] = useState("");

  // Password strength
  const getPasswordStrength = () => {

    if (password.length === 0) {
      return "";
    }

    if (password.length < 6) {
      return "Weak";
    }

    if (
      password.length >= 6 &&
      /[A-Z]/.test(password) &&
      /[0-9]/.test(password)
    ) {
      return "Strong";
    }

    return "Medium";
  };

  const login = (e) => {

    e.preventDefault();

    // Validation
    if (username === "") {
      setError("Username is required");
      return;
    }

    if (password === "") {
      setError("Password is required");
      return;
    }

    // JWT Token Simulation
    const fakeToken =
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9." +
      btoa(username) +
      ".fake-signature";

    const userData = {
      username: username,
      token: fakeToken
    };

    // Remember User
    if (remember) {

      localStorage.setItem(
        "authUser",
        JSON.stringify(userData)
      );

    } else {

      sessionStorage.setItem(
        "authUser",
        JSON.stringify(userData)
      );

    }

    setError("");

    navigate("/");
  };

  return (

    <div className="container">

      <div className="row">

        <div className="col-md-4 col-md-offset-4">

          <div className="panel panel-primary">

            <div className="panel-heading">
              <h3>Login</h3>
            </div>

            <div className="panel-body">

              <form onSubmit={login}>

                {/* Username */}
                <div className="form-group">

                  <label>Username</label>

                  <input
                    type="text"
                    className="form-control"
                    value={username}
                    onChange={(e) =>
                      setUsername(e.target.value)
                    }
                    placeholder="Enter username"
                  />

                </div>

                {/* Password */}
                <div className="form-group">

                  <label>Password</label>

                  <input
                    type="password"
                    className="form-control"
                    value={password}
                    onChange={(e) =>
                      setPassword(e.target.value)
                    }
                    placeholder="Enter password"
                  />

                </div>

                {/* Password Strength */}
                {password && (

                  <p>
                    Password Strength:

                    <strong>
                      {" "}{getPasswordStrength()}
                    </strong>
                  </p>

                )}

                {/* Remember User */}
                <div className="checkbox">

                  <label>

                    <input
                      type="checkbox"
                      checked={remember}
                      onChange={(e) =>
                        setRemember(e.target.checked)
                      }
                    />

                    {" "}Remember User

                  </label>

                </div>

                {/* Error */}
                {error && (

                  <div className="alert alert-danger">
                    {error}
                  </div>

                )}

                <button
                  type="submit"
                  className="btn btn-primary btn-block"
                >
                  Login
                </button>

              </form>

            </div>

          </div>

        </div>

      </div>

    </div>
  );
}

export default Login;