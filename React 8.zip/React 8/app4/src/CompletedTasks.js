import React from "react";

function CompletedTasks() {

  return (

    <div className="container">

      <h2>Completed Tasks</h2>

      <hr />

      <div className="alert alert-success">
        No completed tasks available.
      </div>

    </div>
  );
}

export default CompletedTasks;