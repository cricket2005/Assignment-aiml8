import React, { useState } from "react";

function AddTask() {

  const [header, setHeader] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState("Medium");
  const [category, setCategory] = useState("Academic");

  const addTask = (e) => {

    e.preventDefault();

    alert("Task Added Successfully!");

    console.log({
      header,
      description,
      priority,
      category,
      raisedDate: new Date().toLocaleString(),
      dueDate: "28 Aug 2026",
      status: "Raised"
    });

  };

  return (

    <div className="container">

      <h2>Add Task</h2>

      <form onSubmit={addTask}>

        <div className="form-group">

          <label>Task Header</label>

          <input
            className="form-control"
            value={header}
            onChange={(e) =>
              setHeader(e.target.value)
            }
          />

        </div>

        <div className="form-group">

          <label>Description</label>

          <textarea
            className="form-control"
            value={description}
            onChange={(e) =>
              setDescription(e.target.value)
            }
          />

        </div>

        <div className="form-group">

          <label>Priority</label>

          <select
            className="form-control"
            value={priority}
            onChange={(e) =>
              setPriority(e.target.value)
            }
          >

            <option>High</option>
            <option>Medium</option>
            <option>Low</option>

          </select>

        </div>

        <div className="form-group">

          <label>Category</label>

          <select
            className="form-control"
            value={category}
            onChange={(e) =>
              setCategory(e.target.value)
            }
          >

            <option>Academic</option>
            <option>Personal</option>

          </select>

        </div>

        <button className="btn btn-success">
          Add Task
        </button>

      </form>

    </div>
  );
}

export default AddTask;