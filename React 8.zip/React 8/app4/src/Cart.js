import React, { useState } from "react";

function Cart({
  cart,
  removeItem,
  increaseQuantity,
  decreaseQuantity
}) {

  const [coupon, setCoupon] = useState("");
  const [discount, setDiscount] = useState(0);

  // Calculate subtotal
  const subtotal = cart.reduce(
    (total, item) =>
      total + item.price * item.quantity,
    0
  );

  // Apply coupon
  const applyCoupon = () => {

    if (coupon === "SAVE10") {
      setDiscount(10);
    }
    else if (coupon === "SAVE20") {
      setDiscount(20);
    }
    else {
      setDiscount(0);
      alert("Invalid Coupon Code");
    }

  };

  // Discount amount
  const discountAmount =
    subtotal * discount / 100;

  // Price after discount
  const priceAfterDiscount =
    subtotal - discountAmount;

  // GST 18%
  const gst =
    priceAfterDiscount * 18 / 100;

  // Grand total
  const grandTotal =
    priceAfterDiscount + gst;

  return (
    <div className="cart">

      <h2>Shopping Cart</h2>

      {cart.length === 0 ? (

        <p>Your cart is empty.</p>

      ) : (

        <>

          {cart.map(item => (

            <div className="cart-item" key={item.id}>

              <div>
                <h3>{item.name}</h3>

                <p>
                  Price: ₹{item.price}
                </p>

                <p>
                  Quantity: {item.quantity}
                </p>
              </div>

              <div>

                <button
                  onClick={() =>
                    decreaseQuantity(item.id)
                  }
                >
                  -
                </button>

                <button
                  onClick={() =>
                    increaseQuantity(item.id)
                  }
                >
                  +
                </button>

                <button
                  onClick={() =>
                    removeItem(item.id)
                  }
                >
                  Remove
                </button>

              </div>

            </div>

          ))}

          <hr />

          <h3>
            Subtotal: ₹{subtotal.toFixed(2)}
          </h3>

          <div className="coupon">

            <input
              type="text"
              placeholder="Enter Coupon Code"
              value={coupon}
              onChange={(e) =>
                setCoupon(e.target.value.toUpperCase())
              }
            />

            <button onClick={applyCoupon}>
              Apply Coupon
            </button>

          </div>

          <p>
            Discount ({discount}%):
            ₹{discountAmount.toFixed(2)}
          </p>

          <p>
            Price After Discount:
            ₹{priceAfterDiscount.toFixed(2)}
          </p>

          <p>
            GST (18%):
            ₹{gst.toFixed(2)}
          </p>

          <h2>
            Grand Total:
            ₹{grandTotal.toFixed(2)}
          </h2>

        </>

      )}

    </div>
  );
}

export default Cart;