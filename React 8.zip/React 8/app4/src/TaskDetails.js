import React from "react";
import { useParams } from "react-router-dom";

function TaskDetails() {

  const { id } = useParams();

  return (

    <div className="container">

      <h2>Task Details</h2>

      <hr />

      <p>
        <b>Task ID:</b> {id}
      </p>

      <p>
        <b>Task Header:</b> Complete React Assignment
      </p>

      <p>
        <b>Priority:</b> High
      </p>

      <p>
        <b>Category:</b> Academic
      </p>

      <p>
        <b>Status:</b> Pending
      </p>

    </div>
  );
}

export default TaskDetails;